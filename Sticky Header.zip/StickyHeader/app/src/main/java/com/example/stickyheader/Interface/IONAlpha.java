package com.example.stickyheader.Interface;

public interface IONAlpha {
    void onAlpha(String alphabet,int position);
}
